import requests

if __name__ == "__main__":
    while (1):
        requests.get(url="http://10.196.1.207/2moons/index.php")
